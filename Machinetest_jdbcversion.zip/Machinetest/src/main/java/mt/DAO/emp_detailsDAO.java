package mt.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import mt.Model.emp_details;


public class emp_detailsDAO {
	
	
	private final String sqlquery2 = "Select ID,Name,DOB,mail_id from emp_details where mail_id = ?";
	
		
	public boolean validate(String uname,String pwd,String dbname){
		String expass="";
		Connection con=null;
		try{  
			Class.forName("com.mysql.jdbc.Driver");
			
			if(dbname.equals("emp1")){
			con=DriverManager.getConnection(  
			"jdbc:mysql://localhost:3306/emp1","root","");
			}
			if(dbname.equals("emp")){
			con=DriverManager.getConnection(  
				"jdbc:mysql://localhost:3306/emp","root","");
				}
			//here sonoo is database name, root is username and password  
			Statement stmt=con.createStatement();  
			ResultSet rs=stmt.executeQuery("select password from emp_details where mail_id ='"+uname+"'");  
			while(rs.next())  
			expass=rs.getString(1);  
			con.close();  
			}catch(Exception e){ 
				
				System.out.println(e);
			}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		}
		if(pwd.equals(expass)){
			return true;
		}
		else{
			return false;
		}
	}
	
	public emp_details getdetails(String uname,String dbname){
		emp_details db = new emp_details();
		Connection  con = null;
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			con=DriverManager.getConnection(  
			"jdbc:mysql://localhost:3306/"+dbname,"root","");  
			//here sonoo is database name, root is username and password  
			Statement stmt=con.createStatement();  
			ResultSet rs=stmt.executeQuery("Select ID,Name,DOB,mail_id from emp_details where mail_id = '"+uname+"'");  
			while(rs.next()) { 
			 db.setID(rs.getInt(1));
			db.setName(rs.getString(2));
			db.setDOB(rs.getString(3));
			db.setMail_id(rs.getString(4));
			}
			con.close();  
			}catch(Exception e){ System.out.println(e);
			
			}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		}
		return db;
	}
		
	
}
