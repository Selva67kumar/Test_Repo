package mt.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import mt.DAO.emp_detailsDAO;
import mt.Model.emp_details;

@RestController
public class Maincontroller {


	
	@RequestMapping("/")
	public ModelAndView firstPage() {
		return new ModelAndView("login");
	}
	@RequestMapping("/Authenticate")
	public ModelAndView lcheck(HttpServletRequest request,@RequestParam("uname")String uname,@RequestParam("upwd")String upwd,@RequestParam("dbname")String dbname) {
		System.out.println("---------------"+uname);
		HttpSession session = request.getSession();
		
		emp_detailsDAO ab = new emp_detailsDAO();
 
		if(ab.validate(uname, upwd, dbname)){
			session.setAttribute("token", dbname);
			return new ModelAndView("Getuser");
		}else{
			session.setAttribute("token","");
			return new ModelAndView("login");
		}
		
	}
	@RequestMapping("/GetEmployee")
	public ModelAndView getDetail(HttpServletRequest request,@RequestParam("gname")String gname) {
		HttpSession session = request.getSession();
		String a1 = (String) session.getAttribute("token");
		if("emp".equals(a1)||"emp1".equals(a1)){
		String dbname = a1;	
		emp_detailsDAO ab = new emp_detailsDAO();
		emp_details em = new emp_details();
		em = ab.getdetails(gname,dbname);
		System.out.println("=================="+em.getName());
		
		ModelAndView mv = new ModelAndView("Result");
		mv.addObject("id",em.getID());
		mv.addObject("name",em.getName());
		mv.addObject("dob",em.getDOB());
		mv.addObject("mail",em.getMail_id());
		return mv;
		}else{
			return new ModelAndView("login");
		}
	}
	
}
