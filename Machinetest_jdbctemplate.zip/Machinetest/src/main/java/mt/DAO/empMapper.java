package mt.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import mt.Model.emp_details;

public class empMapper implements RowMapper{

		@Override
		public emp_details mapRow(ResultSet rs, int rowNum) throws SQLException {
			emp_details user = new emp_details();
			user.setID(rs.getInt("ID"));
			user.setName(rs.getString("Name"));
			user.setDOB(rs.getString("DOB"));
			user.setMail_id(rs.getString("mail_id"));
			user.setPassword(rs.getString("password"));
			return user;
		}

}
