package mt.DAO;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import mt.Model.emp_details;

@Repository
public class emp_detailsDAO {

 @Autowired
 JdbcTemplate jdbcTemplate;
	
	
	
	private final String sqlquery2 = "Select ID,Name,DOB,mail_id from emp_details where mail_id = ?";
	
		
	public boolean validate(String uname,String pwd,String dbname){
		List<String> pwdlist = new ArrayList<>();
			System.out.println("--------------"+"Select password from emp_details where mail_id = '"+uname+"';");
		pwdlist.addAll(jdbcTemplate.queryForList("Select password from emp_details; ", String.class));
		System.out.println("--------------"+pwdlist.get(0));
		if(pwd.equals(pwdlist.get(0))){
			return true;
		}else{
			return false;
		}
	}
	
	public emp_details getdetails(String uname){
		
			return (emp_details) jdbcTemplate.queryForObject(sqlquery2, new Object[] { uname }, new empMapper());
		
	}
		
	
}
