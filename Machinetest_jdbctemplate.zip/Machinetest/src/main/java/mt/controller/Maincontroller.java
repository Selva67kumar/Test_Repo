package mt.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import mt.DAO.emp_detailsDAO;
import mt.Model.emp_details;

@RestController
public class Maincontroller {

	@Autowired
private emp_detailsDAO Emp_detailsDAO;	
	
	@RequestMapping("/")
	public ModelAndView firstPage() {
		return new ModelAndView("login");
	}
	@RequestMapping("/logincheck")
	public ModelAndView lcheck(@RequestParam("uname")String uname,@RequestParam("upwd")String upwd,@RequestParam("dbname")String dbname) {
		System.out.println("---------------"+uname);
		

		emp_detailsDAO ab = new emp_detailsDAO();
		emp_details em = new emp_details();
		em = ab.getdetails(uname);
		System.out.println("=================="+em.getName());
		/*if(ab.validate(uname, upwd, dbname)){
			return new ModelAndView("Getuser");
		}else{
			return new ModelAndView("login");
		}*/
		return new ModelAndView("login");
	}
	
}
